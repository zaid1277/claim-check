from collections.abc import Callable

from app.core.errors import ProviderError
from app.services.article_extraction import Article, extract_article, make_passages
from app.services.search import SearchProvider, search_queries


def collect_evidence(
    claim: str,
    search: SearchProvider,
    extract: Callable[[str], Article] = extract_article,
    max_sources: int = 10,
    passage_words: int = 100,
    max_passages: int = 100,
) -> list[tuple[Article, str]]:
    """Keep search failures visible; skip individual unreadable sources."""
    seen: set[str] = set()
    passages = []
    for query in search_queries(claim):
        if len(seen) >= max_sources:
            break
        for result in search.search(query):
            if result.url in seen or len(seen) >= max_sources:
                continue
            seen.add(result.url)
            try:
                article = extract(result.url)
            except ProviderError:
                continue
            remaining = max_passages - len(passages)
            passages.extend(
                (article, text)
                for text in make_passages(article.text, passage_words)[:remaining]
            )
            if len(passages) >= max_passages:
                return passages
    return passages
