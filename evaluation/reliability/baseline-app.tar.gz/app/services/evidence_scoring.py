from app.core.settings import Settings
from app.schemas.investigation import Assessment, Evidence, Verdict


def aggregate(support: float, contradict: float, settings: Settings) -> Verdict:
    if support + contradict < settings.minimum_evidence:
        return "INSUFFICIENT_EVIDENCE"
    if support >= settings.dominance_ratio * contradict:
        return "SUPPORTED"
    if contradict >= settings.dominance_ratio * support:
        return "UNSUPPORTED"
    return "MIXED_EVIDENCE"


def assess(claim: str, evidence: list[Evidence], settings: Settings) -> Assessment:
    """Keep opposing totals separate so disagreement cannot disappear by subtraction."""
    for item in evidence:
        item.evidence_score = (
            item.similarity * item.stance_confidence * item.source_weight
        )
    support = sum(e.evidence_score for e in evidence if e.stance == "support")
    contradict = sum(e.evidence_score for e in evidence if e.stance == "contradict")
    verdict = aggregate(support, contradict, settings)
    if verdict == "INSUFFICIENT_EVIDENCE":
        explanation = (
            "The retained evidence is too weak or incomplete "
            "for a supported assessment."
        )
    else:
        explanation = {
            "SUPPORTED": "The retained passages predominantly support the claim.",
            "UNSUPPORTED": "The retained passages predominantly contradict the claim.",
            "MIXED_EVIDENCE": "The retained passages contain substantial disagreement.",
        }[verdict]
    citations = [
        f"[{i + 1}] {item.stance}: “{item.passage}”"
        for i, item in enumerate(evidence)
        if item.stance != "neutral"
    ]
    explanation += " " + " ".join(citations)
    return Assessment(
        claim=claim,
        verdict=verdict,
        explanation=explanation.strip(),
        support_total=support,
        contradict_total=contradict,
        evidence=evidence,
    )
