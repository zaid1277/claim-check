from app.core.settings import Settings
from app.schemas.investigation import Assessment, Evidence
from app.services.collection import collect_evidence
from app.services.embeddings import EmbeddingProvider
from app.services.evidence_scoring import assess
from app.services.nli import NLIProvider
from app.services.retrieval import rank_passages
from app.services.search import SearchProvider
from app.services.source_quality import source_quality


def check_claim(
    claim: str,
    settings: Settings,
    search: SearchProvider,
    embeddings: EmbeddingProvider,
    nli: NLIProvider,
) -> Assessment:
    """Run the fixed retrieval/classification pipeline with replaceable providers."""
    candidates = collect_evidence(
        claim,
        search,
        max_sources=settings.max_sources,
        passage_words=settings.passage_words,
        max_passages=settings.max_passages,
    )
    candidates = candidates[: settings.max_passages]
    ranked = rank_passages(
        claim,
        [text for _, text in candidates],
        embeddings,
        settings.top_k,
        settings.min_similarity,
    )
    evidence = []
    for match in ranked:
        article, passage = candidates[match.index]
        stance, confidence = nli.classify(claim, passage)
        kind, weight = source_quality(article.domain, settings)
        evidence.append(
            Evidence(
                title=article.title,
                url=article.url,
                domain=article.domain,
                published_at=article.published_at,
                passage=passage,
                similarity=match.similarity,
                stance=stance,
                stance_confidence=confidence,
                source_type=kind,
                source_weight=weight,
                evidence_score=0,
            )
        )
    return assess(claim, evidence, settings)
