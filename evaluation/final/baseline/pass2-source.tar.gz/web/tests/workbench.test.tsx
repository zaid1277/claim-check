import { fireEvent, render, screen, cleanup } from "@testing-library/react";
import { afterEach, expect, test, vi } from "vitest";
import Workbench from "../components/workbench";

const fixture = {
  id: "00000000-0000-0000-0000-000000000001",
  created_at: "2026-09-01T00:00:00Z",
  mode: "fixture",
  share_slug: null,
  model_metadata: {},
  assessments: [
    {
      claim: "A test claim",
      verdict: "INSUFFICIENT_EVIDENCE",
      explanation: "No evidence.",
      evidence: [],
      support_total: 0,
      contradict_total: 0,
    },
  ],
};

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function enterClaim() {
  fireEvent.change(screen.getByLabelText("Claim to investigate"), {
    target: { value: "A test claim" },
  });
  fireEvent.click(screen.getByRole("button", { name: "Check claim" }));
}

test("focus moves to the result after the asynchronous response is rendered", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn().mockResolvedValue({ ok: true, json: async () => fixture }),
  );
  render(<Workbench />);
  enterClaim();
  const heading = await screen.findByRole("heading", {
    name: "Investigation result",
  });
  expect(document.activeElement).toBe(heading);
  expect(screen.getByText(/Demonstration fixtures/)).toBeTruthy();
});

test("an unavailable provider is shown as an error, not an evidence result", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn().mockResolvedValue({
      ok: false,
      json: async () => ({ error: { message: "Search is unavailable." } }),
    }),
  );
  render(<Workbench />);
  enterClaim();
  expect((await screen.findByRole("alert")).textContent).toBe(
    "Search is unavailable.",
  );
  expect(
    screen.queryByRole("article", { name: "Investigation result" }),
  ).toBeNull();
});

test("checking state exposes a status and prevents duplicate submissions", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn(() => new Promise(() => {})),
  );
  render(<Workbench />);
  enterClaim();
  expect((await screen.findByRole("status")).textContent).toContain(
    "Checking evidence",
  );
  expect(
    (
      screen.getByRole("button", {
        name: "Check claim",
      }) as HTMLButtonElement
    ).disabled,
  ).toBe(true);
});

test("claim selection cannot submit an empty selection", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        text: "A proposed factual sentence.",
        claims: ["A proposed factual sentence."],
      }),
    }),
  );
  render(<Workbench initialUrl="https://example.org/article" />);
  fireEvent.click(screen.getByRole("button", { name: "Propose claims" }));
  const checkbox = await screen.findByLabelText("Investigate claim 1");
  fireEvent.click(checkbox);
  expect(
    (
      screen.getByRole("button", {
        name: "Investigate selected claims",
      }) as HTMLButtonElement
    ).disabled,
  ).toBe(true);
});
