from dataclasses import dataclass
from urllib.parse import urlsplit

import trafilatura

from app.core.errors import ProviderError
from app.services.url_fetch import fetch_html


@dataclass
class Article:
    url: str
    title: str
    domain: str
    text: str
    published_at: str | None = None


def parse_article(html: str, url: str) -> Article:
    """Return plain article text; scripts and markup never reach the UI."""
    # Bibliography entries identify sources; they are not evidence assertions.
    text = trafilatura.extract(
        html,
        include_comments=False,
        include_tables=False,
        prune_xpath=(
            "//*[contains(concat(' ', normalize-space(@class), ' '), ' references ')"
            " or contains(concat(' ', normalize-space(@class), ' '), ' reflist ')"
            " or @role='doc-bibliography']"
            " | //*[@id='Bibliography']/parent::div"
            "/following-sibling::*[1][self::ul or self::ol]"
        ),
    )
    if not text or len(text.strip()) < 50:
        raise ProviderError("No readable article was found. Paste the text instead.")
    metadata = trafilatura.extract_metadata(html, default_url=url)
    return Article(
        url=url,
        title=(metadata.title if metadata else None)
        or urlsplit(url).hostname
        or "Source",
        domain=urlsplit(url).hostname or "",
        text=text,
        published_at=metadata.date if metadata else None,
    )


def extract_article(url: str) -> Article:
    html, final_url = fetch_html(url)
    return parse_article(html, final_url)


def make_passages(text: str, words_per_passage: int = 100) -> list[str]:
    from app.services.propositions import sentence_texts

    passages, current = [], []
    for sentence in sentence_texts(text):
        words = sentence.split()
        if len(words) > words_per_passage:
            if current:
                passages.append(" ".join(current))
                current = []
            passages.extend(
                " ".join(words[i : i + words_per_passage])
                for i in range(0, len(words), words_per_passage)
            )
        elif len(current) + len(words) > words_per_passage:
            passages.append(" ".join(current))
            current = words
        else:
            current.extend(words)
    if current:
        passages.append(" ".join(current))
    return passages
