from app.core.settings import Settings
from app.schemas.investigation import Assessment, Evidence, Verdict
from app.services.independence import same_content, source_group


def aggregate(support: float, contradict: float, settings: Settings) -> Verdict:
    if support + contradict < settings.minimum_evidence:
        return "INSUFFICIENT_EVIDENCE"
    if support >= settings.dominance_ratio * contradict:
        return "SUPPORTED"
    if contradict >= settings.dominance_ratio * support:
        return "UNSUPPORTED"
    return "MIXED_EVIDENCE"


def assess(claim: str, evidence: list[Evidence], settings: Settings) -> Assessment:
    """Keep opposing totals separate so disagreement cannot disappear by subtraction."""
    for item in evidence:
        item.evidence_score = (
            item.similarity * item.stance_confidence * item.source_weight
        )
    retained = []
    used = set()
    for item in sorted(evidence, key=lambda e: -e.evidence_score):
        item.independence_group = source_group(item.url)
        item.counted = item.stance != "neutral"
        if not item.counted:
            continue
        key = (item.independence_group, item.stance)
        duplicate = any(
            old.stance == item.stance
            and same_content(item.passage, old.passage, settings.duplicate_similarity)
            for old in retained
        )
        if key in used or duplicate:
            item.counted = False
            item.exclusion_reason = (
                "Repeated source or near-duplicate content; "
                "not independent confirmation."
            )
        else:
            used.add(key)
            retained.append(item)
    support = sum(e.evidence_score for e in retained if e.stance == "support")
    contradict = sum(e.evidence_score for e in retained if e.stance == "contradict")
    verdict = aggregate(support, contradict, settings)
    if verdict == "INSUFFICIENT_EVIDENCE":
        explanation = (
            "The retained evidence is too weak or incomplete "
            "for a supported assessment."
        )
    else:
        explanation = {
            "SUPPORTED": "The retained passages predominantly support the claim.",
            "UNSUPPORTED": "The retained passages predominantly contradict the claim.",
            "MIXED_EVIDENCE": "The retained passages contain substantial disagreement.",
        }[verdict]
    citations = [
        f"[{i + 1}] {item.stance}: “{item.passage}”"
        for i, item in enumerate(evidence)
        if item.stance != "neutral" and item.counted
    ]
    explanation += " " + " ".join(citations)
    return Assessment(
        claim=claim,
        verdict=verdict,
        explanation=explanation.strip(),
        support_total=support,
        contradict_total=contradict,
        evidence=evidence,
    )
