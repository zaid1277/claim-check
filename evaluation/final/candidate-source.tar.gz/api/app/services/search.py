from dataclasses import dataclass
from typing import Protocol

import httpx

from app.core.errors import ProviderError
from app.core.settings import Settings


@dataclass
class SearchResult:
    url: str
    title: str
    snippet: str = ""
    provider_score: float | None = None


class SearchProvider(Protocol):
    def search(self, query: str) -> list[SearchResult]: ...


class BraveSearch:
    def __init__(self, settings: Settings, client: httpx.Client | None = None):
        self.settings = settings
        self.client = client

    def search(self, query: str) -> list[SearchResult]:
        """Query Brave without falling back to invented evidence."""
        if not self.settings.brave_search_api_key:
            raise ProviderError("Live search is not configured.")
        key = self.settings.brave_search_api_key.get_secret_value()
        try:
            with httpx.Client(timeout=15, trust_env=False) as default_client:
                response = (self.client or default_client).get(
                    "https://api.search.brave.com/res/v1/web/search",
                    params={"q": query, "count": self.settings.search_results},
                    headers={"X-Subscription-Token": key},
                )
                response.raise_for_status()
                return [
                    SearchResult(url=item["url"], title=item["title"])
                    for item in response.json().get("web", {}).get("results", [])
                ]
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {401, 403}:
                from app.services.provider_setup import reject_key

                reject_key("brave", self.settings.brave_search_api_key)
                raise ProviderError("Brave Search rejected this API key.") from exc
            if exc.response.status_code == 429:
                raise ProviderError(
                    "Brave Search quota is exhausted. Try again later."
                ) from exc
            raise ProviderError(
                "Web search is temporarily unavailable. Try again later."
            ) from exc
        except httpx.TimeoutException as exc:
            raise ProviderError("Web search took too long. Please try again.") from exc
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise ProviderError(
                "Search is unavailable. Please try again later."
            ) from exc


class TavilySearch:
    def __init__(self, settings: Settings, client: httpx.Client | None = None):
        self.settings = settings
        self.client = client

    def search(self, query: str) -> list[SearchResult]:
        if not self.settings.tavily_api_key:
            raise ProviderError("Tavily search is not configured.")
        try:
            with httpx.Client(timeout=15, trust_env=False) as default_client:
                response = (self.client or default_client).post(
                    "https://api.tavily.com/search",
                    headers={
                        "Authorization": "Bearer "
                        + self.settings.tavily_api_key.get_secret_value()
                    },
                    json={
                        "query": query,
                        "max_results": self.settings.search_results,
                        "search_depth": "basic",
                        "include_answer": False,
                        "include_raw_content": False,
                        "include_images": False,
                        "auto_parameters": False,
                    },
                )
                response.raise_for_status()
                payload = response.json()
                if not isinstance(payload, dict) or not isinstance(
                    payload.get("results"), list
                ):
                    raise ValueError("Invalid search response")
                results = []
                for item in payload["results"]:
                    if (
                        not isinstance(item, dict)
                        or not isinstance(item.get("url"), str)
                        or not isinstance(item.get("title"), str)
                    ):
                        raise ValueError("Invalid search result")
                    score = item.get("score")
                    results.append(
                        SearchResult(
                            url=item["url"],
                            title=item["title"],
                            snippet=item.get("content")
                            if isinstance(item.get("content"), str)
                            else "",
                            provider_score=float(score)
                            if isinstance(score, (int, float))
                            else None,
                        )
                    )
                return results
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {401, 403}:
                from app.services.provider_setup import reject_key

                reject_key("tavily", self.settings.tavily_api_key)
                raise ProviderError("Tavily rejected this API key.") from exc
            if exc.response.status_code in {429, 432, 433}:
                raise ProviderError(
                    "Tavily's usage limit was reached. Try again later."
                ) from exc
            raise ProviderError(
                "Tavily is temporarily unavailable. Try again later."
            ) from exc
        except httpx.TimeoutException as exc:
            raise ProviderError(
                "Tavily took too long to respond. Please try again."
            ) from exc
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise ProviderError(
                "Tavily could not be reached or read. Please try again."
            ) from exc


class FixtureSearch:
    def __init__(self, results: list[SearchResult]):
        self.results = results

    def search(self, query: str) -> list[SearchResult]:
        return list(self.results)


def search_queries(claim: str) -> list[str]:
    return [claim, f"{claim} evidence research", f"{claim} official statistics"]


def make_search(settings: Settings) -> SearchProvider:
    if settings.search_provider == "brave":
        return BraveSearch(settings)
    if settings.search_provider == "mock":
        if settings.provider_mode != "fixture":
            raise ProviderError("Mock search is unavailable for live investigations.")
        return FixtureSearch([])
    return TavilySearch(settings)
