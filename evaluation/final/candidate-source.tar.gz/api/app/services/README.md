# Investigation services

The services follow PROJECT_SPEC.md: reviewed claims, search/article passages,
embeddings/cosine ranking, NLI, source heuristics, evidence scoring and grounded
explanation. Providers are replaceable for tests. Live failures never silently
switch to demonstration evidence. See ../../../../docs/ml-notes.md.
