class ProviderError(Exception):
    """An external operation failed; its internal details stay out of responses."""
