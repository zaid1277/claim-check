from datetime import UTC, datetime

from app.core.settings import Settings
from app.schemas.investigation import Assessment, AtomicAssessment, Evidence
from app.services.collection import collect_evidence
from app.services.embeddings import EmbeddingProvider
from app.services.evidence_scoring import assess
from app.services.nli import NLIProvider
from app.services.propositions import decompose_claim, proposition_check
from app.services.retrieval import rank_passages
from app.services.search import SearchProvider
from app.services.source_quality import source_quality


def temporal_exclusion(
    claim: str, published_at: str | None, settings: Settings
) -> str | None:
    """Explicitly current claims require recent dates; age does not establish truth."""
    import re

    if not re.search(r"\b(currently|current|today|now|latest)\b", claim, re.I):
        return None
    try:
        published = datetime.fromisoformat(published_at[:10]).replace(tzinfo=UTC)
    except (ValueError, TypeError):
        return "Currentness cannot be established without a usable publication date."
    age = (datetime.now(UTC) - published).days
    if age < 0 or age > settings.current_evidence_days:
        return "The publication date is outside the current-evidence window."
    return None


def gate_stance(claim, passage, stance, confidence, published_at, settings):
    """Retain the model output separately from conservative evidence eligibility."""
    exclusion = temporal_exclusion(claim, published_at, settings)
    if stance == "contradict":
        addressed, reason = proposition_check(claim, passage)
        if not addressed:
            exclusion = reason
        elif confidence < settings.min_contradiction_confidence:
            exclusion = (
                "Contradiction confidence is below the required operating point."
            )
    return ("neutral" if exclusion else stance), exclusion


def check_atomic(claim, settings, search, embeddings, nli):
    candidates = collect_evidence(
        claim,
        search,
        max_sources=settings.max_sources,
        passage_words=settings.passage_words,
        max_passages=settings.max_passages,
    )[: settings.max_passages]
    unique = {}
    for article, passage in candidates:
        key = " ".join(passage.casefold().split())
        old = unique.get(key)
        if (
            old is None
            or source_quality(article.domain, settings)[1]
            > source_quality(old[0].domain, settings)[1]
        ):
            unique[key] = (article, passage)
    candidates = list(unique.values())
    ranked = rank_passages(
        claim,
        [text for _, text in candidates],
        embeddings,
        settings.top_k,
        settings.min_similarity,
    )
    evidence = []
    for match in ranked:
        article, passage = candidates[match.index]
        stance, confidence = nli.classify(claim, passage)
        raw_stance = stance
        stance, exclusion = gate_stance(
            claim, passage, stance, confidence, article.published_at, settings
        )
        kind, weight = source_quality(article.domain, settings)
        evidence.append(
            Evidence(
                title=article.title,
                url=article.url,
                domain=article.domain,
                published_at=article.published_at,
                passage=passage,
                similarity=match.similarity,
                stance=stance,
                raw_stance=raw_stance,
                stance_confidence=confidence,
                source_type=kind,
                source_weight=weight,
                evidence_score=0,
                exclusion_reason=exclusion,
                atomic_claim=claim,
            )
        )
    return assess(claim, evidence, settings)


def check_claim(
    claim: str,
    settings: Settings,
    search: SearchProvider,
    embeddings: EmbeddingProvider,
    nli: NLIProvider,
) -> Assessment:
    """Verify explicit propositions independently and preserve the original claim."""
    atoms = decompose_claim(claim, settings.max_atomic_claims)
    results = [check_atomic(atom, settings, search, embeddings, nli) for atom in atoms]
    evidence, coverage = [], []
    for result in results:
        indices = list(range(len(evidence), len(evidence) + len(result.evidence)))
        evidence.extend(result.evidence)
        coverage.append(
            AtomicAssessment(
                claim=result.claim,
                verdict=result.verdict,
                support_total=result.support_total,
                contradict_total=result.contradict_total,
                evidence_indices=indices,
            )
        )
    if len(results) == 1:
        results[0].claim = claim
        results[0].atomic_claims = coverage
        return results[0]
    verdicts = {r.verdict for r in results}
    if "UNSUPPORTED" in verdicts:
        verdict = "UNSUPPORTED"
    elif "MIXED_EVIDENCE" in verdicts:
        verdict = "MIXED_EVIDENCE"
    elif verdicts == {"SUPPORTED"}:
        verdict = "SUPPORTED"
    else:
        verdict = "INSUFFICIENT_EVIDENCE"
    explanation = "Each proposition was assessed separately. " + " ".join(
        f"{r.claim} — {r.verdict.replace('_', ' ').lower()}." for r in results
    )
    return Assessment(
        claim=claim,
        verdict=verdict,
        explanation=explanation,
        support_total=sum(r.support_total for r in results),
        contradict_total=sum(r.contradict_total for r in results),
        evidence=evidence,
        atomic_claims=coverage,
    )
