"""Small, conservative grammar checks; never supply facts absent from the input."""

import re
from functools import lru_cache

from app.core.errors import ProviderError


@lru_cache(maxsize=1)
def parser():
    import spacy

    try:
        return spacy.load("en_core_web_sm")
    except OSError as exc:
        raise ProviderError(
            "Install the English parser before live investigations."
        ) from exc


def sentence_texts(text: str) -> list[str]:
    # Keep decimal values intact; preserve adjacent sentences for coreference in chunks.
    return [
        s.strip()
        for s in re.split(r'(?<=[.!?])\s+(?=[A-Z\d"“])|\n+', text)
        if s.strip()
    ]


def decompose_claim(claim: str, limit: int = 4) -> list[str]:
    """Split explicit coordinated finite predicates; leave ambiguous scope intact."""
    if " and " not in claim.lower():
        return [claim]
    doc = parser()(claim)
    if any(
        t.tag_ == "MD"
        or t.dep_ == "neg"
        or t.lower_ in {"if", "unless", "or", "because"}
        for t in doc
    ):
        return [claim]
    boundaries = [
        t
        for t in doc
        if t.lower_ == "and"
        and t.dep_ == "cc"
        and t.i + 1 < len(doc)
        and doc[t.i + 1].pos_ in {"VERB", "AUX", "PRON"}
    ]
    if not boundaries or len(boundaries) >= limit:
        return [claim]
    first = claim[: boundaries[0].idx].strip().rstrip(",")
    left = parser()(first)
    subject = next(
        (t for t in left if t.dep_ in {"nsubj", "nsubjpass"} and t.head.dep_ == "ROOT"),
        None,
    )
    if subject is None or subject.pos_ == "PRON":
        return [claim]
    subject_text = left[subject.left_edge.i : subject.right_edge.i + 1].text
    atoms = [first.rstrip(". ") + "."]
    for i, boundary in enumerate(boundaries):
        end = boundaries[i + 1].idx if i + 1 < len(boundaries) else len(claim)
        part = claim[boundary.idx + len(boundary.text) : end].strip().rstrip("., ")
        right = parser()(part)
        if not right or right[0].pos_ not in {"VERB", "AUX", "PRON"}:
            return [claim]
        if right[0].lower_ in {"it", "they"}:
            part = subject_text + part[len(right[0].text) :]
        elif right[0].pos_ == "PRON":
            return [claim]
        else:
            auxiliary = ""
            if right[0].tag_ == "VBN":
                auxiliary = " ".join(
                    t.text for t in left if t.dep_ in {"aux", "auxpass"}
                )
                if not auxiliary:
                    return [claim]
            part = " ".join(p for p in (subject_text, auxiliary, part) if p)
        atoms.append(part + ".")
    return atoms


def proposition_check(claim: str, passage: str) -> tuple[bool, str]:
    """Require a grammatical subject anchor and a predicate anchor for contradiction."""
    claim_doc = parser()(claim)
    passage_doc = parser()(passage)
    subjects = [t for t in claim_doc if t.dep_ in {"nsubj", "nsubjpass"}]
    if not subjects:
        return False, "No unambiguous subject was identified."
    subject = subjects[0]
    anchors = {t.lemma_.lower() for t in subject.subtree if t.pos_ in {"NOUN", "PROPN"}}
    passage_words = {t.lemma_.lower() for t in passage_doc if not t.is_punct}
    if not anchors or not anchors <= passage_words:
        return False, "The passage does not explicitly identify the same subject."
    root = subject.head
    predicates = {root.lemma_.lower()} - {"be", "have", "do"}
    # Copular/location/quantity claims need a content predicate, not just "is".
    if not predicates:
        predicates = {
            t.lemma_.lower()
            for t in root.children
            if t.dep_ in {"attr", "acomp", "dobj"} and t.pos_ != "NUM"
        }
        if not predicates and any(t.dep_ == "prep" for t in root.children):
            predicates = {t.lemma_.lower() for t in root.children if t.dep_ == "prep"}
    if not predicates & passage_words:
        return False, "The passage does not explicitly address the same predicate."
    # A previous reporting period is not a contradiction of this period's statistic.
    years = set(re.findall(r"\b(?:19|20)\d{2}\b", claim))
    quantities = [t for t in claim_doc if t.like_num and t.text not in years]
    if (
        years
        and quantities
        and not years <= set(re.findall(r"\b(?:19|20)\d{2}\b", passage))
    ):
        return False, "The measurement refers to a different or unspecified period."
    # Evidence of a subset alone cannot disprove a universal assertion.
    if any(t.lower_ in {"all", "every", "each"} for t in claim_doc):
        if any(t.lower_ in {"some", "one"} for t in passage_doc) and not any(
            t.dep_ == "neg" or t.lower_ in {"except", "only", "unfixed", "exempt"}
            for t in passage_doc
        ):
            return False, "A subset is described without an explicit counterexample."
    return True, "Subject and predicate are explicitly addressed."
