from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, PostgresDsn, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Resolve from this file so starting the API from another directory still works.
    model_config = SettingsConfigDict(
        env_file=Path(__file__).resolve().parents[3] / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
        env_ignore_empty=True,
    )

    allow_runtime_provider_keys: bool = False

    search_provider: Literal["tavily", "brave", "mock"] | None = None
    tavily_api_key: SecretStr | None = None
    brave_search_api_key: SecretStr | None = None
    search_results: int = Field(default=5, ge=1, le=20)
    provider_mode: Literal["fixture", "live"] = "fixture"

    embedding_batch_size: int = Field(default=16, ge=1, le=64)
    nli_max_tokens: int = Field(default=512, ge=128, le=512)
    min_claim_chars: int = Field(default=20, ge=3, le=1000)

    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    min_similarity: float = Field(default=0.35, ge=0, le=1)
    top_k: int = Field(default=10, ge=1, le=30)
    passage_words: int = Field(default=100, ge=20, le=200)
    max_sources: int = Field(default=10, ge=1, le=20)

    nli_model: str = "cross-encoder/nli-deberta-v3-small"
    min_nli_confidence: float = Field(default=0.65, ge=0, le=1)
    min_contradiction_confidence: float = Field(default=0.85, ge=0, le=1)
    max_atomic_claims: int = Field(default=4, ge=1, le=5)
    duplicate_similarity: float = Field(default=0.9, ge=0, le=1)
    current_evidence_days: int = Field(default=365, ge=1)
    minimum_evidence: float = Field(default=0.5, gt=0)
    dominance_ratio: float = Field(default=2.0, gt=1)
    max_passages: int = Field(default=100, ge=1, le=300)
    source_weights: dict[str, float] = {
        "research": 1.0,
        "official": 0.95,
        "institution": 0.90,
        "reporting": 0.75,
        "general": 0.55,
        "unknown": 0.30,
    }
    source_domains: dict[str, str] = {
        "nature.com": "research",
        "science.org": "research",
        "reuters.com": "reporting",
        "apnews.com": "reporting",
        "bbc.com": "reporting",
        "blogspot.com": "unknown",
        "substack.com": "unknown",
    }

    max_claims: int = Field(default=5, ge=1, le=5)

    max_image_bytes: int = 5_000_000
    max_image_pixels: int = 12_000_000

    requests_per_minute: int = Field(default=30, ge=1, le=300)

    @model_validator(mode="after")
    def valid_source_heuristics(self):
        if self.provider_mode == "live" and self.search_provider == "mock":
            raise ValueError("The mock provider is only available in fixture mode.")
        required = {
            "research",
            "official",
            "institution",
            "reporting",
            "general",
            "unknown",
        }
        if set(self.source_weights) != required:
            raise ValueError("Configure all six source-weight categories.")
        if any(not 0 <= weight <= 1 for weight in self.source_weights.values()):
            raise ValueError("Source weights must be between zero and one.")
        if any(kind not in required for kind in self.source_domains.values()):
            raise ValueError("Source domains must use configured weight categories.")
        return self

    database_url: PostgresDsn | None = None


@lru_cache
def get_settings() -> Settings:
    return Settings()
